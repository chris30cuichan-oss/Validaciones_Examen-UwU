#ifndef VALIDACIONES_H
#define VALIDACIONES_H

// Funciones auxiliares de validación pura
int validarEntero(int valor, int min, int max);
int validarDecimal(float valor, float min, float max);
int validarTexto(const char *cadena);

// Funciones de lectura obligatorias usando punteros (Paso por referencia)
void leerEnteroValidado(const char *mensaje, int min, int max, int *resultado);
void leerDecimalValidado(const char *mensaje, float min, float max, float *resultado);
void leerTextoValidado(const char *mensaje, char *resultado, int tamano_max);

#endif